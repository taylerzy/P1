package com.example.myfirstapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen101);


        LinearLayout lLayout = (LinearLayout) findViewById(R.id.activity_main);
        setContentView(lLayout);
        lLayout.setOrientation(LinearLayout.VERTICAL);
        TextView text = new TextView(this);
        text.setText("WSU CEG3900 Mobile and Cloud Computing – Taylor Luehrs");

        Button b = new Button(this);
        b.setText("Next");
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                Intent i = new Intent(MainActivity.this, Activity2.class);
                startActivity(i);
            }
        });


        lLayout.addView(text);
        lLayout.addView(b);



    }
}
