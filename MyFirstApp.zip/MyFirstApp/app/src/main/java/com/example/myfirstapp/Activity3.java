package com.example.myfirstapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;

public class Activity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen301);

        Button b = (Button) findViewById(R.id.btnClick4);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                setResult(RESULT_OK);
                finish();
            }
        });

        Button b2 = (Button) findViewById(R.id.btnClick5);
        b2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                Intent i = new Intent(Activity3.this, Activity4.class);
                startActivity(i);
            }
        });

        /*TextView text = new TextView(this);
        text.setText("WSU CEG3900 Mobile and Cloud Computing – Taylor Luehrs");
        setContentView(text);*/
    }
}
